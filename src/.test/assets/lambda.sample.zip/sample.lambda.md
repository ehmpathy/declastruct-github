sample lambda zip placeholder
